-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: patient
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doctorappointments`
--

DROP TABLE IF EXISTS `doctorappointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctorappointments` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `APPOINTMENTID` int DEFAULT NULL,
  `DATE` text,
  `SCHEDULETIMESTART` text,
  `SCHEDULETIMEEND` text,
  `APPOINTMENTTITLE` text,
  `PATIENTSLOT` int DEFAULT NULL,
  `TIMEALLOTEDPERPATIENT` int DEFAULT NULL,
  `ROOM` text,
  `DOCTOR` text,
  `EXPERTISE` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctorappointments`
--

LOCK TABLES `doctorappointments` WRITE;
/*!40000 ALTER TABLE `doctorappointments` DISABLE KEYS */;
INSERT INTO `doctorappointments` VALUES (1,1016,'2024-06-03','07:30AM','08:30AM','Check Up',0,30,'Room 101','Eyyy ryyyy','Dentist'),(2,1016,'2024-06-04','07:30AM','08:30AM','Check Up',0,30,'Room 101','Eyyy ryyyy','Dentist'),(3,1016,'2024-06-05','07:30AM','08:30AM','Check Up',1,30,'Room 101','Eyyy ryyyy','Dentist'),(4,1017,'2024-06-03',NULL,NULL,'Check Up',5,30,'Room 103','Eyyy ryyyy','Dentist'),(5,1018,'2024-06-03','09:00 AM','10:00 AM','Check Up',2,30,'Room 104','Eyyy ryyyy','Dentist'),(6,1019,'2024-06-10','09:30 AM','11:30 AM','Check up',4,30,'Room 103','Eyyy ryyyy','Dentist'),(7,1020,'2024-06-03','10:30 AM','11:00 AM','Check Up',1,30,'Room 101','Eyyy ryyyy','Dentist'),(8,1021,'2024-06-07','12:00 PM','01:00 PM','Check Up',2,30,'Room 103','Eyyy ryyyy','Dentist'),(9,1022,'2024-06-07','08:00 AM','11:30 AM','Check Up',7,30,'Room 103','Eyyy ryyyy','Dentist'),(10,1023,'2024-06-14','08:30 AM','12:00 PM','check up',7,30,'Room 105','Eyyy ryyyy','Dentist'),(11,1024,'2024-06-12','07:30 AM','09:30 AM','Check Up',4,30,'Room 101','Eyyy ryyyy','Dentist'),(12,1024,'2024-06-20','07:30 AM','09:30 AM','Check Up',4,30,'Room 105','Eyyy ryyyy','Dentist'),(13,1025,'2024-06-03','06:00AM','08:00AM','Check Up',3,30,'Room 101','John Mark Magdasal','Radiology'),(14,1025,'2024-06-05','06:00AM','08:00AM','Check Up',3,30,'Room 101','John Mark Magdasal','Radiology'),(15,1025,'2024-06-07','06:00AM','08:00AM','Check Up',4,30,'Room 101','John Mark Magdasal','Radiology'),(16,1026,'2024-06-14','06:00 PM','09:00 PM','check up',6,30,'Room 105','John Mark Magdasal','Radiology'),(17,1027,'2024-06-13','01:00 AM','02:00 AM','cheee',2,30,'Room 102','Eyyy ryyyy','Dentist'),(18,1027,'2024-06-07','01:00 AM','02:00 AM','cheee',2,30,'Room 103','Eyyy ryyyy','Dentist'),(19,1028,'2024-06-03','07:30AM','11:30AM','Check up',8,30,'Room 104','Jayson Limonesro','Dentist'),(20,1028,'2024-06-04','07:30AM','11:30AM','Check up',8,30,'Room 104','Jayson Limonesro','Dentist'),(21,1029,'2024-06-13','07:00 AM','09:00 AM','asasda',4,30,'Room 106','Eyyy ryyyy','Dentist'),(22,1029,'2024-06-14','07:00 AM','09:00 AM','asasda',4,30,'Room 102','Eyyy ryyyy','Dentist'),(23,1030,'2024-06-13','07:00 AM','09:00 AM','asda',4,30,'Room 101','Eyyy ryyyy','Dentist'),(24,1030,'2024-06-14','07:00 AM','09:00 AM','asda',4,30,'Room 105','Eyyy ryyyy','Dentist');
/*!40000 ALTER TABLE `doctorappointments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-01 11:12:24
